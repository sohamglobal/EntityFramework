﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class _Default : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {

    }

    protected void Submit(object sender, EventArgs e)
    {
        try
        {
            var context = new praffulldbEntities();
            customers obj = new customers();
            obj.name = TextBox1.Text;
            obj.city = TextBox2.Text;
            obj.amount = Convert.ToDouble(TextBox3.Text);

            context.customers.Add(obj);
            int n=context.SaveChanges();
            context.Dispose();

            if (n > 0)
                Response.Write("New Customer Added Successfully..");
            else
                Response.Write("New Customer Reg Failed");
        }
        catch (Exception) { }
    }
}