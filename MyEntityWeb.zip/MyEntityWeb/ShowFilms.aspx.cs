﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class ShowFilms : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        var context = new praffulldbEntities();
        var items = context.films.Where(item => item.actor.Contains("amir"));

        var arr = items.ToArray();
        GridView1.DataSource = arr;
        GridView1.DataBind();
        
    }
}