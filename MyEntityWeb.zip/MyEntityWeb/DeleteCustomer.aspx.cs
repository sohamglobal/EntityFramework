﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class DeleteCustomer : System.Web.UI.Page
{
    public string msg = "";
    protected void Page_Load(object sender, EventArgs e)
    {
        try
        {
            int id = Convert.ToInt32(Request.QueryString["id"]);
            var context = new praffulldbEntities();

            customers obj = context.customers.FirstOrDefault(r => r.id == id);

            context.customers.Remove(obj);
            int n = context.SaveChanges();
            context.Dispose();

            if (n > 0)
                msg="Customer deleted successfully..";
            else
                msg="Customer deletion Failed";

        }
        catch (Exception ex) { msg = ex.Message; }
    }
}