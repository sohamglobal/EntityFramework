﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class UpdateCustomer : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {

    }

    protected void Submit(object sender, EventArgs e)
    {
        try
        {
            var context = new praffulldbEntities();
            customers obj = context.customers.FirstOrDefault(r => r.name == TextBox1.Text);

            obj.city = TextBox2.Text;
            obj.amount = Convert.ToDouble(TextBox3.Text);

            
            int n=context.SaveChanges();
            context.Dispose();

            if (n > 0)
                Response.Write("Customer updated successfully..");
            else
                Response.Write("Customer update Failed");
        }
        catch (Exception ex) { Response.Write(ex.Message); }
    }
}