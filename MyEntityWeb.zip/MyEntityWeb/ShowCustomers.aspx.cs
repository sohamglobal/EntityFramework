﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class ShowCustomers : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        try
        {
            var context = new praffulldbEntities();
            var item = context.customers.ToArray();
            GridView1.DataSource = item;
            GridView1.DataBind();
        }
        catch (Exception) { }
    }
}